<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="overworld type 2" tilewidth="16" tileheight="16" tilecount="152" columns="19">
 <image source="../../../../../../Videos/Free Pixel Art overworld tileset/PNG/overworld type 2.png" width="304" height="128"/>
</tileset>
