import arcade
class game(arcade.Window) :
    def __init__(self) :
        self.